##Authors

- Greg Lamp
- Austin Ogilvie

##Patches
- Colin Dickson
- stonebig

##Fork author
- Alexander Plavin